
self.addEventListener("install", e => {
  e.waitUntil(
    caches.open("cotton-odyssey").then(cache => {
      return cache.addAll(["./", "./index.html", "./manifest.json", "./photos/icon.png"]);
    })
  );
});

self.addEventListener("fetch", e => {
  e.respondWith(
    caches.match(e.request).then(r => r || fetch(e.request))
  );
});
